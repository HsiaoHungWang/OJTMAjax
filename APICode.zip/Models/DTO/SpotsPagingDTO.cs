﻿namespace OJTMAjax.Models.DTO
{
    public class SpotsPagingDTO
    {
        public int TotalPages { get; set; }
        public List<SpotImagesSpot>? SpotsResult { get; set; }

    }
}
